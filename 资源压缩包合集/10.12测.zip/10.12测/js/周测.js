function Popup() {
    // this.data=obj.data
    this.box=this.getEl('.box')
    
    this.init()
}

Popup.prototype.init = function () {
    this.bindEvent()
}

Popup.prototype.bindEvent = function () {
    this.box.addEventListener('click',(e)=>{
        let target=e.target||window.event.srcElement
        if(target.className==='tit'){
            this.$('.tip').classList.add('show')
        }
        if(target.className==='con'){
            this.$('.tip').classList.add('show')
        }
        if(target.className==='btn'){
            this.$('.tip').classList.add('show')
        }
        if(target.className==='event'){
            this.$('.tip').classList.add('show')
        }
        if(target.className==='set'){
            this.$('.tip').classList.add('show')
        }
        if(target.className==='pic'){
            this.$('.tip').classList.add('show')
        }
        if(target.className==='close'){
            this.$('.tip').classList.add('show')
        }
        if(target.className==='load'){
            this.$('.loading').classList.add('show')
        }
    })
}

Popup.prototype.$=function(el,parent){
    parent=parent||document
    return parent.querySelector(el)
}
Popup.prototype.gets=function(el,parent){
    parent=parent||document
    return [...parent.querySelectorAll(el)]
}
Popup.prototype.getEl=function(el){
    if(el.nodeType===1)return el
    else if(typeof el==='string')return this.$(el)
        else{ throw new Error('el类型错误 maybe an element or className')}
}