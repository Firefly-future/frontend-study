

var  ysf = ["+" , "*" , "/"];

// 页面初始化问题
var num1 = random( 1 , 1000 );  // 操作第一个数
var num2 = random( 1 , 1000 );  // 操作第二个数
var ydfI = random( 0 , ysf.length - 1 );  // 运算符下标
$(".question").innerText = num1 + ysf[ydfI] + num2 +  " = ?"









function random( min , max ){
    return Math.floor(Math.random() * ( max - min + 1 ) + min)
}

function $(el){
    return document.querySelector(el)
}