<script setup>
import { onMounted } from 'vue'
import { RouterView } from 'vue-router'
import { getCity } from '@/services'

onMounted(() => {
  // 获取定位
  navigator.geolocation.getCurrentPosition(async pos => {
    const res = await getCity({
      latitude: pos.coords.latitude,
      longitude: pos.coords.longitude
    })
    console.log(res.data.data.city)
    localStorage.setItem('GPS_City', JSON.stringify(res.data.data.city))
  }, e => {
    console.log('获取定位失败')
  })
})
</script>

<template>
  <RouterView />
</template>

<style lang='scss' scoped>

</style>
