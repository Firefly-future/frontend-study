import dayjs from "dayjs"

export const formatDate = time => {
  const date = dayjs(time)
  const d = date.format('d')
  const list = ['周日', '周一','周二','周三','周四','周五','周六']
  return list[d] + date.format('MM月DD日')
}
