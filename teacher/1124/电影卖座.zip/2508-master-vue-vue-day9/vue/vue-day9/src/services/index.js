import axios from 'axios'

// 电影列表
export const getFilmList = ({
  pageNum = 1,
  pageSize = 10,
  type = 1
} = {}) => {
  return axios.get('https://m.maizuo.com/gateway', {
    params: {
      cityId: JSON.parse(localStorage.getItem('currentCity')).cityId,
      pageNum,
      pageSize,
      type,
      k: 4892903
    },
    headers: {
      'x-client-info': '{"a":"3000","ch":"1002","v":"5.2.1","e":"17406486386215998793318401"}',
      'x-host': 'mall.film-ticket.film.list'
    }
  })
}

// 电影详情
export const getFilmDetail = (filmId) => {
  return axios.get('https://m.maizuo.com/gateway', {
    params: {
      filmId,
      k: 9583944
    },
    headers: {
      'x-client-info': '{"a":"3000","ch":"1002","v":"5.2.1","e":"17406486386215998793318401"}',
      'x-host': 'mall.film-ticket.film.info'
    }
  })
}

// 影院列表
export const getCinemaList = ({ ticketFlag = 1 } = {}) => {
  return axios.get('https://m.maizuo.com/gateway', {
    params: {
      cityId: JSON.parse(localStorage.getItem('currentCity')).cityId,
      ticketFlag,
      k: 3865988
    },
    headers: {
      'x-client-info': '{"a":"3000","ch":"1002","v":"5.2.1","e":"17406486386215998793318401"}',
      'x-host': 'mall.film-ticket.cinema.list'
    }
  })
}

// 影院详情
export const getCinemaInfo = cinemaId => {
  return axios.get('https://m.maizuo.com/gateway/', {
    params: {
      cinemaId,
      k: 6728459
    },
    headers: {
      'x-client-info': '{"a":"3000","ch":"1002","v":"5.2.1","e":"17406486386215998793318401"}',
      'x-host':  'mall.film-ticket.cinema.info'
    }
  })
}

// 影院的电影列表
export const getCinemaFilm = cinemaId => {
  return axios.get('https://m.maizuo.com/gateway/', {
    params: {
      cinemaId,
      k: 6728459
    },
    headers: {
      'x-client-info': '{"a":"3000","ch":"1002","v":"5.2.1","e":"17406486386215998793318401"}',
      'x-host': 'mall.film-ticket.film.cinema-show-film'
    }
  })
}

// 影院的电影播放场次
export const getCinemaFilmSchedule = ({
  cinemaId,
  filmId,
  date
}) => {
  return axios.get('https://m.maizuo.com/gateway/', {
    params: {
      cinemaId,
      filmId,
      date,
      k: 9448691
    },
    headers: {
      'x-client-info': '{"a":"3000","ch":"1002","v":"5.2.1","e":"17406486386215998793318401"}',
      'x-host': 'mall.film-ticket.schedule.list'
    }
  })
}

// 城市列表
export const getCities = () => {
  return axios.get('https://m.maizuo.com/gateway/', {
    params: {
      k: 5236719
    },
    headers: {
      'x-client-info': '{"a":"3000","ch":"1002","v":"5.2.1","e":"17406486386215998793318401"}',
      'x-host': 'mall.film-ticket.city.list'
    }
  })
}


// 获取当前城市
export const getCity = ({ latitude, longitude }) => {
  return axios.get('/api', {
    params: {
      k: 7206473
    },
    headers: {
      'x-client-info': '{"a":"3000","ch":"1002","v":"5.2.1","e":"17406486386215998793318401"}',
      'x-host': 'mall.film-ticket.city.locate',
      latitude,
      longitude,
    }
  })
}
