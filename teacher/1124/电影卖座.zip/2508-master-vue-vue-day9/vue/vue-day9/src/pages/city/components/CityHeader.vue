<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'

const emits = defineEmits(['cancel'])
const searchText = defineModel()
const router = useRouter()
const showCancel = ref(false)
const currentCity = ref(JSON.parse(localStorage.getItem('currentCity')))


const onCancel = () => {
  showCancel.value = false
  emits('cancel')
}
</script>

<template>
  <div class="header">
    <div class="title-bar">
      <div class="back" @click="router.back()">back</div>
      当前城市-{{ currentCity.name }}
    </div>
    <div class="search-bar">
      <input
        type="text"
        placeholder="搜索城市或拼音"
        v-model="searchText"
        @focus="showCancel = true"
      >
      <div v-if="showCancel" class="cancel" @click="onCancel">取消</div>
    </div>
  </div>
</template>

<style lang='scss' scoped>
.header {
  height: 100px;
}
.title-bar {
  line-height: 50px;
  text-align: center;
  position: relative;
  background: #fff;
  .back {
    width: 50px;
    position: absolute;
    top: 0;
    left: 0;
  }
}
.search-bar {
  height: 50px;
  background: #f4f4f4;
  padding: 10px 15px;
  display: flex;
  input {
    flex: 1;
    background: #fff;
    padding: 0 10px 0 30px;
    border: none;
    outline: none;
  }
  .cancel {
    margin-left: 15px;
    line-height: 30px;
    font-size: 14px;
  }
}
</style>
