<script setup>
const props = defineProps(['list'])
const emits = defineEmits(['select'])

</script>

<template>
  <div class="list-wrap">
    <div class="empty" v-if="list.length === 0">没有对应的结果</div>
    <ul v-else>
      <li v-for="city in list" :key="city.cityId" @click="emits('select', city)">{{ city.name }}</li>
    </ul>
  </div>
</template>

<style lang='scss' scoped>
.list-wrap {
  height: 100%;
  overflow: auto;
  ul {
    padding-left: 16px;
  }
  li {
    background-color: #fff;
    height: 100%;
    line-height: 48px;
    font-size: 14px;
    border-bottom: 1px solid #ddd;
  }
}
.empty {
  line-height: 100px;
  text-align: center;
}
</style>
