<script setup>
import { getCities } from '@/services'
import CityHeader from './components/CityHeader.vue'
import CityList from './components/CityList.vue'
import SearchResult from './components/SearchResult.vue'
import { ref, computed, watch } from 'vue'
import { useRouter } from 'vue-router'

const router = useRouter()
const showResult = ref(false)
const cities = ref([])
const cityGroup = ref([])
const searchText = ref('')

const hotList = computed(() => {
  return cities.value.filter(item => item.isHot)
})

// 搜索结果
const searchResult = computed(() => {
  if (!searchText.value) return []
  return cities.value.filter(v => {
    return v.name.includes(searchText.value) || v.pinyin.toLowerCase().includes(searchText.value.toLowerCase())
  })
})

watch(searchText, () => {
  showResult.value = true
})

// 获取所有城市列表
const getData = async () => {
  try {
    const res = await getCities()
    console.log(res.data.data.cities)
    cities.value = res.data.data.cities
    cityGroup.value = formatCities(res.data.data.cities)
  } catch(e) {
    console.log(e)
  }
}

getData()

// 给城市列表分组
const formatCities = list => {
  const res = []
  list.forEach(item => {
    const firstLetter = item.pinyin[0]
    const curGroup = res.find(v => v.title === firstLetter)
    if (curGroup) {
      curGroup.list.push(item)
    } else {
      res.push({
        title: firstLetter,
        list: [item]
      })
    }
  })
  return res
}

const selectCity = city => {
  console.log('选择的城市', city)
  localStorage.setItem('currentCity', JSON.stringify(city))
  router.back()
}

</script>

<template>
  <div class="detail">
    <CityHeader
      v-model="searchText"
      @cancel="showResult = false"
    />
    <main>
      <SearchResult v-if="showResult" :list="searchResult" @select="selectCity" />
      <CityList v-else :list="cityGroup" :hotList="hotList" @select="selectCity" />
    </main>
  </div>
</template>

<style lang='scss' scoped>
.detail {
  width: 100vw;
  height: 100vh;
  display: flex;
  flex-direction: column;
  main {
    flex: 1;
    overflow: hidden;
  }
}
</style>
