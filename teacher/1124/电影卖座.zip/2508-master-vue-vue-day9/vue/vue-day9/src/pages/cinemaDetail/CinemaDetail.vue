<script setup>
import { ref, computed, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import {
  getCinemaInfo,
  getCinemaFilm,
  getCinemaFilmSchedule
} from '@/services'
import { Swiper, SwiperSlide } from 'swiper/vue'
import 'swiper/css'
import { formatDate } from '@/utils'
import dayjs from "dayjs"

const route = useRoute()
const router = useRouter()
const cinemaInfo = ref({}) // 影院详情
const films = ref([]) // 电影列表
const activeIndex = ref(0) // 当前电影下标
const dateIndex = ref(0) // 选择的日期下标
const schedules = ref([]) // 电影场次

// 当前选中的电影
const currentFilm = computed(() => {
  return films.value[activeIndex.value] || {}
})
// 演员
const actors = computed(() => {
  return currentFilm.value.actors?.map(v => v.name).join(' | ')
})

let swiperIns = null
// 初始化轮播图
const onSwiper = swiper => {
  swiperIns = swiper
}

// 切换轮播图
const onSlideChange = (swiper) => {
  activeIndex.value = swiper.activeIndex
  dateIndex.value = 0
}

// 跳转电影详情
const goFilmDetail = () => {
  router.push({
    path: '/film/detail',
    query: {
      id: currentFilm.value.filmId
    }
  })
}

// 获取电影和日期下标
const getInitIndex = () => {
  // 根据参数去电影列表中查找下标
  const filmIndex = films.value.findIndex(v => v.filmId === Number(route.params.filmId))
  if (filmIndex > -1) {
    activeIndex.value = filmIndex
    // 跳转到对应的轮播图
    swiperIns.slideTo(activeIndex.value)
  }
  // 根据参数去电影时间中查找下标
  const dateInd = currentFilm.value.showDate.indexOf(Number(route.params.date))
  if (dateInd > -1) {
    dateIndex.value = dateInd
  }
}

// 获取影院详情
const getCinemaData = async () => {
  try {
    const res = await getCinemaInfo(route.params.cinemaId)
    console.log(res.data.data.cinema)
    cinemaInfo.value = res.data.data.cinema
  } catch(e) {
    console.log(e)
  }
}
// 获取电影列表
const getCinemaFilmData = async () => {
  try {
    const res = await getCinemaFilm(route.params.cinemaId)
    console.log(res.data.data.films)
    films.value = res.data.data.films
    getInitIndex()
  } catch(e) {
    console.log(e)
  }
}
// 获取电影场次
const getCinemaFilmScheduleData = async () => {
  try {
    const res = await getCinemaFilmSchedule({
      cinemaId: route.params.cinemaId,
      filmId: currentFilm.value.filmId,
      date: currentFilm.value.showDate[dateIndex.value]
    })
    console.log(res.data.data.schedules)
    schedules.value = res.data.data.schedules
  } catch(e) {
    console.log(e)
  }
}

getCinemaFilmData()
getCinemaData()

watch([currentFilm, dateIndex], () => {
  getCinemaFilmScheduleData()
  router.replace({
    params: {
      filmId: currentFilm.value.filmId,
      date: currentFilm.value.showDate[dateIndex.value]
    }
  })
})

</script>

<template>
  <div class="detail">
    <div class="title-bar">
      <div class="back">返回</div>
    </div>
    <h2 class="title">{{ cinemaInfo.name }}</h2>
    <div class="cinema-info">
      <div class="tags">
        <span v-for="tag in cinemaInfo.services" :key="tag.name">{{ tag.name }}</span>
      </div>
      <div class="desc">
        <p>{{ cinemaInfo.address }}</p>
        <a :href="`tel:${cinemaInfo.telephones}`">电话</a>
      </div>
    </div>
    <swiper
      class="swiper"
      slidesPerView="4"
      spaceBetween="30"
      :centeredSlides="true"
      @swiper="onSwiper"
      @slideChange="onSlideChange"
    >
      <swiper-slide
        v-for="(item, index) in films"
        :key="item.filmId"
        :class="['slide', { active: activeIndex === index }]"
      >
        <img :src="item.poster" />
      </swiper-slide>
      <div class="triangle"></div>
      <div class="bg" :style="{ backgroundImage: `url(${currentFilm.poster})` }"></div>
    </swiper>
    <div class="film-info">
      <div @click="goFilmDetail">
        <h3>{{ currentFilm.name }}</h3>
        <p>
          {{ currentFilm.runtime }}分钟 | {{ actors }}
        </p>
      </div>
      <div class="data-nav">
        <span
          v-for="(date, index) in currentFilm.showDate"
          :key="date"
          :class="{ active: dateIndex === index }"
          @click="dateIndex = index"
        >
          {{ formatDate(date * 1000) }}
        </span>
      </div>
    </div>
    <div class="schedules">
      <div
        v-for="item in schedules"
        :key="item.scheduleId"
        class="schedules-item"
      >
        <div class="time">
          <p>{{ dayjs(item.showAt * 1000).format('HH:mm') }}</p>
          <p>{{ dayjs(item.endAt * 1000).format('HH:mm') }}散场</p>
        </div>
        <div class="info">
          <p>{{ item.filmLanguage }}{{ item.imagery }}</p>
          <p>{{ item.hallName }}</p>
        </div>
        <div class="price">¥{{ item.salePrice / 100 }}</div>
        <button>购票</button>
      </div>
    </div>
  </div>
</template>

<style lang='scss' scoped>
.detail {
  width: 100vw;
  height: 100vh;
  overflow: auto;
}
.title-bar {
  height: 45px;
  line-height: 45px;
  position: sticky;
  top: 0;
  z-index: 11;
}
.title {
  text-align: center;
  font-size: 16px;
  line-height: 45px;
  position: sticky;
  top: 0;
  background: #fff;
  z-index: 10;
}
.cinema-info {
  .tags {
    display: flex;
    justify-content: center;
    padding: 10px 0;
    span {
      border: 1px solid sandybrown;
      margin: 0 5px;
      font-size: 12px;
      padding: 3px 6px;
    }
  }
  .desc {
    display: flex;
    height: 45px;
    border-top: 1px solid #ddd;
    border-bottom: 1px solid #ddd;
    line-height: 45px;
    font-size: 14px;
    p {
      flex: 1;
      padding-left: 20px;
    }
    a {
      width: 45px;
      height: 45px;
      text-align: center;
      border-left: 1px solid #ddd;
    }
  }
}
.swiper {
  height: 160px;
  padding: 15px 0;
  position: relative;
  overflow: hidden;
  .bg {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-size: 100% 100%;
    filter: blur(10px);
    overflow: hidden;
    &::after {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba($color: #ffffff, $alpha: .5);
    }
  }
}
.slide {
  display: flex;
  justify-content: center;
  align-items: flex-end;
  width: 130px;
  img {
    width: 72px;
    height: 104px;
    transition: 0.3s linear;
  }
  &.active {
    img {
      width: 90px;
      height: 130px;
    }
  }
}
.triangle {
  position: absolute;
  bottom: 0;
  left: 50%;
  transform: translateX(-50%);
  width: 20px;
  height: 10px;
  background: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAUCAYAAAD/Rn+7AAAAAXNSR0IArs4c6QAAAH1JREFUSA3N0EsKgDAMBNB4cu3JYyJ1oRTtZ/IZGLIbHiEChpkPLXASN1Vxcq7kQgpJP/dODqSoWrgbG4v8wcUiO3ExyEGcL3IS54NcxNkiQTgbJBiHRRrhMEhj3BrSCTeHdMaNIYNwfchg3DcyCa6NTIZ7IDfFEdEuzZhyAkTR3AC3/R6VAAAAAElFTkSuQmCC) no-repeat center;
  background-size: contain;
  z-index: 1;
}
.film-info {
  text-align: center;
  padding-top: 10px;
  position: sticky;
  top: 45px;
  background: #fff;
  h3 {
    line-height: 30px;
    font-size: 16px;
  }
  p {
    font-size: 12px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    width: 80%;
    margin: 0 auto;
    line-height: 30px;
    span {
      margin: 0 5px;
    }
  }
}
.data-nav {
  line-height: 45px;
  border-top: 1px solid #ddd;
  border-bottom: 1px solid #ddd;
  display: flex;
  overflow: auto;
  span {
    margin: 0 10px;
    flex-shrink: 0;
    font-size: 14px;
    &.active {
      color: tomato;
    }
  }
  &::-webkit-scrollbar {
    display: none;
  }
}
.schedules-item {
  display: flex;
  align-items: center;
  border-bottom: 1px solid #ddd;
  padding: 5px;
  .time {
    width: 100px;
  }
  .info {
    flex: 1;
  }
  .price {
    margin: 0 10px;
  }
  button {
    height: 30px;
    width: 60px;
  }
}
</style>
