<script setup>
import { ref } from 'vue'

const props = defineProps(['list', 'hotList'])
const emits = defineEmits(['select'])

const GPS_City = ref(JSON.parse(localStorage.getItem('GPS_City')))
const groupEl = ref(null)
const groupWrapEl = ref(null)
const tipText = ref(null)
const link = index => {
  groupWrapEl.value.scrollTop = groupEl.value.children[index].offsetTop
  showTip(props.list[index].title)
}

let timeoutId = null
const showTip = text => {
  tipText.value = text
  if (timeoutId) clearTimeout(timeoutId)
  timeoutId = setTimeout(() => {
    tipText.value = null
  }, 2000)
}
</script>

<template>
  <div class="list-wrap">
    <div class="group-list" ref="groupWrapEl">
      <div class="recommend-city">
        <div class="hot-city">
          <h3>GPS定位城市</h3>
          <ul>
            <li @click="emits('select', GPS_City)">{{ GPS_City.name }}</li>
          </ul>
        </div>
        <div class="hot-city">
          <h3>热门城市</h3>
          <ul>
            <li v-for="city in hotList" :key="city.cityId" @click="emits('select', city)">{{ city.name }}</li>
          </ul>
        </div>
      </div>
      <div ref="groupEl">
        <div
          v-for="item in list"
          :key="item.title"
          class="group-item"
        >
          <h3>{{ item.title }}</h3>
          <ul>
            <li v-for="city in item.list" :key="city.cityId" @click="emits('select', city)">{{ city.name }}</li>
          </ul>
        </div>
      </div>
    </div>
    <div class="letters">
      <p
        v-for="(item, index) in list"
        :key="item.title"
        @click="link(index)"
      >{{ item.title }}</p>
    </div>
  </div>
  <Teleport to="body">
    <div class="tip" v-if="tipText">{{ tipText }}</div>
  </Teleport>
</template>

<style lang='scss' scoped>
.list-wrap {
  height: 100%;
  display: flex;
  background: #fff;
}
.recommend-city {
  padding-left: 15px;
  h3 {
    font-size: 13px;
    color: #797d82;
    line-height: 40px;
  }
  ul {
    display: flex;
    flex-wrap: wrap;
    li {
      width: calc((100% / 3) - 10px);
      text-align: center;
      margin: 0 5px 15px 5px;
      -webkit-box-sizing: border-box;
      box-sizing: border-box;
      background: #f4f4f4;
      font-size: 12px;
      line-height: 30px;
    }
  }
}
.group-list {
  overflow: auto;
  flex: 1;
  position: relative;
  scroll-behavior: smooth;
  &::-webkit-scrollbar {
    display: none;
  }
}
.group-item {
  h3 {
    background-color: #f4f4f4;
    color: #797d82;
    padding: 0 0 0 15px;
    height: 30px;
    line-height: 30px;
    font-weight: normal;
    font-size: 12px;
  }
  ul {
    padding-left: 16px;
  }
  li {
    background-color: #fff;
    height: 100%;
    line-height: 48px;
    font-size: 14px;
    border-bottom: 1px solid #ddd;
  }
}
.letters {
  width: 20px;
  font-size: 12px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  p {
    line-height: 20px;
  }
}
.tip {
  position: fixed;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 50px;
  height: 50px;
  text-align: center;
  line-height: 50px;
  color: #fff;
  background: rgba($color: #000000, $alpha: .7);
  border-radius: 5px;
  font-size: 20px;
}
</style>
