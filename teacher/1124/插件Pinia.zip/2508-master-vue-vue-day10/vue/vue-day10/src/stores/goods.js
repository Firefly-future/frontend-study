import { defineStore } from 'pinia'
import { computed, reactive, ref } from 'vue'

// 创建 store
export const useGoodsStore = defineStore('goods', () => {
  const goods = ref(['苹果', '香蕉'])
  

  return {
    goods
  }
})