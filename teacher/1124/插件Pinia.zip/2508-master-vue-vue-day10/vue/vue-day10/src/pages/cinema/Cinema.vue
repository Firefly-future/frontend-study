<script setup>
import { storeToRefs } from 'pinia'
import { useUserStore } from '../../stores/user'

const userStore = useUserStore()

// 直接解构 count ，不是响应式变量，修改 count 时 stroe 中的数据不更新
// const { count } = userStore

// 跟 store 中的 count 建立响应式连接
// const { count } = storeToRefs(userStore)

const add = () => {
  console.log(count)
  
  // console.log(count.value++)
  // userStore.addAge(1)
}
</script>

<template>
  <h2>影院</h2>
  <button @click="add">count: {{ count }}</button>
  <!-- <div>{{ user }}</div> -->
</template>

<style lang='scss' scoped>

</style>
