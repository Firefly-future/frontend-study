import { createRouter, createWebHashHistory } from 'vue-router'
import Home from '@/pages/home/Home.vue'
import Film from '@/pages/film/Film.vue'
import Cinema from '@/pages/cinema/Cinema.vue'
import Mine from '@/pages/mine/Mine.vue'

// 创建路由实例
const router = createRouter({
  history: createWebHashHistory(),
  routes: [
    {
      path: '/home',
      name: 'home',
      component: Home,
      redirect: '/home/film',
      children: [
        {
          path: '/home/film',
          name: 'film',
          component: Film
        },
        {
          path: '/home/cinema',
          name: 'cinema',
          component: Cinema
        },
        {
          path: '/home/mine',
          name: 'mine',
          component: Mine,
          meta: {
            isAuth: true
          }
        },
      ]
    },
    {
      // 匹配所有路由
      path: '/:pathMatch(.*)*',
      redirect: '/home'
    }
  ],
})



export default router
