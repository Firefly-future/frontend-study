import { createApp } from 'vue'
import App from './App.vue'
import './style/common.scss'
import router from './router'
import { createPinia } from 'pinia'


const pinia = createPinia()
const app = createApp(App)

// 使用路由插件
app.use(router)
// 使用 pinia 插件
app.use(pinia)
app.mount('#app')


// 多页面应用（multiple page application） MPA
// 单页面应用（single page application）SPA
// 路由：让单页面应用可以实现多页面的功能
